<?php $this->load->view('templates/user/teacher_header'); ?>

<?php $this->load->view($template); ?>

<?php $this->load->view('templates/user/teacher_footer'); ?>
