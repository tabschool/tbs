<?php $this->load->view('templates/user/header'); ?>

<?php $this->load->view($template); ?>

<?php $this->load->view('templates/user/footer'); ?>
