
    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo TEACHER_THEME_URL ?>plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo TEACHER_THEME_URL ?>plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo TEACHER_THEME_URL ?>plugins/metisMenu/jquery.metisMenu.js"></script> 
	  <script src="<?php echo TEACHER_THEME_URL ?>scripts/jquery-ui.js"></script>
    <script type="text/javascript">  var BASEURL= '<?php echo base_url(); ?>';  </script>

<script>H5PIntegration = {"baseUrl":"http:\/\/webmosk.com\/tab\/wordpress","url":"\/tab\/wordpress\/wp-content\/uploads\/h5p","postUserStatistics":true,"ajax":{"setFinished":"http:\/\/webmosk.com\/tab\/wordpress\/wp-admin\/admin-ajax.php?token=f1f33fd873&action=h5p_setFinished","contentUserData":"http:\/\/webmosk.com\/tab\/wordpress\/wp-admin\/admin-ajax.php?token=02ad7cbfa5&action=h5p_contents_user_data&content_id=:contentId&data_type=:dataType&sub_content_id=:subContentId"},"saveFreq":false,"siteUrl":"http:\/\/webmosk.com\/tab\/wordpress","l10n":{"H5P":{"fullscreen":"Fullscreen","disableFullscreen":"Disable fullscreen","download":"Download","copyrights":"Rights of use","embed":"Embed","size":"Size","showAdvanced":"Show advanced","hideAdvanced":"Hide advanced","advancedHelp":"Include this script on your website if you want dynamic sizing of the embedded content:","copyrightInformation":"Rights of use","close":"Close","title":"Title","author":"Author","year":"Year","source":"Source","license":"License","thumbnail":"Thumbnail","noCopyrights":"No copyright information available for this content.","downloadDescription":"Download this content as a H5P file.","copyrightsDescription":"View copyright information for this content.","embedDescription":"View the embed code for this content.","h5pDescription":"Visit H5P.org to check out more cool content.","contentChanged":"This content has changed since you last used it.","startingOver":"You'll be starting over.","by":"by","showMore":"Show more","showLess":"Show less","subLevel":"Sublevel","confirmDialogHeader":"Confirm action","confirmDialogBody":"Please confirm that you wish to proceed. This action is not reversible.","cancelLabel":"Cancel","confirmLabel":"Confirm","licenseU":"Undisclosed","licenseCCBY":"Attribution","licenseCCBYSA":"Attribution-ShareAlike","licenseCCBYND":"Attribution-NoDerivs","licenseCCBYNC":"Attribution-NonCommercial","licenseCCBYNCSA":"Attribution-NonCommercial-ShareAlike","licenseCCBYNCND":"Attribution-NonCommercial-NoDerivs","licenseCC40":"4.0 International","licenseCC30":"3.0 Unported","licenseCC25":"2.5 Generic","licenseCC20":"2.0 Generic","licenseCC10":"1.0 Generic","licenseGPL":"General Public License","licenseV3":"Version 3","licenseV2":"Version 2","licenseV1":"Version 1","licensePD":"Public Domain","licenseCC010":"CC0 1.0 Universal (CC0 1.0) Public Domain Dedication","licensePDM":"Public Domain Mark","licenseC":"Copyright"}},"hubIsEnabled":true,"user":{"name":"admin","mail":"harshpal.khurana@tabschool.in"},"core":{"styles":["\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p-confirmation-dialog.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p-core-button.css?ver=1.9.4"],"scripts":["\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/jquery.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-event-dispatcher.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-x-api-event.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-x-api.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-content-type.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-confirmation-dialog.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-action-bar.js?ver=1.9.4"]},"loadedJs":[],"loadedCss":[],"editor":{"filesPath":"\/tab\/wordpress\/wp-content\/uploads\/h5p\/editor","fileIcon":{"path":"http:\/\/webmosk.com\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/images\/binary-file.png","width":50,"height":50},"ajaxPath":"http:\/\/webmosk.com\/tab\/wordpress\/wp-admin\/admin-ajax.php?token=9bfeaa2a47&action=h5p_","libraryUrl":"http:\/\/webmosk.com\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/","copyrightSemantics":{"name":"copyright","type":"group","label":"Copyright information","fields":[{"name":"title","type":"text","label":"Title","placeholder":"La Gioconda","optional":true},{"name":"author","type":"text","label":"Author","placeholder":"Leonardo da Vinci","optional":true},{"name":"year","type":"text","label":"Year(s)","placeholder":"1503 - 1517","optional":true},{"name":"source","type":"text","label":"Source","placeholder":"http:\/\/en.wikipedia.org\/wiki\/Mona_Lisa","optional":true,"regexp":{"pattern":"^http[s]?:\/\/.+","modifiers":"i"}},{"name":"license","type":"select","label":"License","default":"U","options":[{"value":"U","label":"Undisclosed"},{"value":"CC BY","label":"Attribution","versions":[{"value":"4.0","label":"4.0 International"},{"value":"3.0","label":"3.0 Unported"},{"value":"2.5","label":"2.5 Generic"},{"value":"2.0","label":"2.0 Generic"},{"value":"1.0","label":"1.0 Generic"}]},{"value":"CC BY-SA","label":"Attribution-ShareAlike","versions":[{"value":"4.0","label":"4.0 International"},{"value":"3.0","label":"3.0 Unported"},{"value":"2.5","label":"2.5 Generic"},{"value":"2.0","label":"2.0 Generic"},{"value":"1.0","label":"1.0 Generic"}]},{"value":"CC BY-ND","label":"Attribution-NoDerivs","versions":[{"value":"4.0","label":"4.0 International"},{"value":"3.0","label":"3.0 Unported"},{"value":"2.5","label":"2.5 Generic"},{"value":"2.0","label":"2.0 Generic"},{"value":"1.0","label":"1.0 Generic"}]},{"value":"CC BY-NC","label":"Attribution-NonCommercial","versions":[{"value":"4.0","label":"4.0 International"},{"value":"3.0","label":"3.0 Unported"},{"value":"2.5","label":"2.5 Generic"},{"value":"2.0","label":"2.0 Generic"},{"value":"1.0","label":"1.0 Generic"}]},{"value":"CC BY-NC-SA","label":"Attribution-NonCommercial-ShareAlike","versions":[{"value":"4.0","label":"4.0 International"},{"value":"3.0","label":"3.0 Unported"},{"value":"2.5","label":"2.5 Generic"},{"value":"2.0","label":"2.0 Generic"},{"value":"1.0","label":"1.0 Generic"}]},{"value":"CC BY-NC-ND","label":"Attribution-NonCommercial-NoDerivs","versions":[{"value":"4.0","label":"4.0 International"},{"value":"3.0","label":"3.0 Unported"},{"value":"2.5","label":"2.5 Generic"},{"value":"2.0","label":"2.0 Generic"},{"value":"1.0","label":"1.0 Generic"}]},{"value":"GNU GPL","label":"General Public License","versions":[{"value":"v3","label":"Version 3"},{"value":"v2","label":"Version 2"},{"value":"v1","label":"Version 1"}]},{"value":"PD","label":"Public Domain","versions":[{"value":"-","label":"-"},{"value":"CC0 1.0","label":"CC0 1.0 Universal"},{"value":"CC PDM","label":"Public Domain Mark"}]},{"value":"C","label":"Copyright"}]},{"name":"version","type":"select","label":"License Version","options":[]}]},"assets":{"css":["\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p-confirmation-dialog.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p-core-button.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/libs\/darkroom.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/styles\/css\/h5p-hub-client.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/styles\/css\/fonts.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/styles\/css\/application.css?ver=1.9.4"],"js":["\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/jquery.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-event-dispatcher.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-x-api-event.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-x-api.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-content-type.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-confirmation-dialog.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-action-bar.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5p-hub-client.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-semantic-structure.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-library-selector.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-form.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-text.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-html.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-number.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-textarea.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-file-uploader.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-file.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-image.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-image-popup.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-av.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-group.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-boolean.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-list.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-list-editor.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-library.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-library-list-cache.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-select.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-selector-hub.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-selector-legacy.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-dimensions.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-coordinates.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/scripts\/h5peditor-none.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-editor-php-library\/ckeditor\/ckeditor.js?ver=1.9.4"]},"deleteMessage":"Are you sure you wish to delete this content?","apiVersion":{"majorVersion":1,"minorVersion":14}}};</script>
<script type="text/javascript">
addLoadEvent = function(func){if(typeof jQuery!="undefined")jQuery(document).ready(func);else if(typeof wpOnload!='function'){wpOnload=func;}else{var oldonload=wpOnload;wpOnload=function(){oldonload();func();}}};
var ajaxurl = '/tab/wordpress/wp-admin/admin-ajax.php',
  pagenow = 'h5p-content_page_h5p_new',
  typenow = '',
  adminpage = 'h5p-content_page_h5p_new',
  thousandsSeparator = ',',
  decimalPoint = '.',
  isRtl = 0;
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var commonL10n = {"warnDelete":"You are about to permanently delete these items from your site.\nThis action cannot be undone.\n 'Cancel' to stop, 'OK' to delete.","dismiss":"Dismiss this notice.","collapseMenu":"Collapse Main menu","expandMenu":"Expand Main menu"};var heartbeatSettings = {"nonce":"a90de34ffc"};var authcheckL10n = {"beforeunload":"Your session has expired. You can log in again from this page or go to the login page.","interval":"180"};/* ]]> */
</script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-admin/load-scripts.php?c=1&amp;load%5B%5D=hoverIntent,common,admin-bar,svg-painter,heartbeat,wp-auth-check&amp;ver=4.8.3'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/jquery.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-event-dispatcher.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-x-api-event.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-x-api.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-content-type.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-confirmation-dialog.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-action-bar.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-editor-php-library/scripts/h5peditor-editor.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/admin/scripts/h5p-editor.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-editor-php-library/language/en.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/jquery.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-display-options.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/admin/scripts/h5p-toggle.js?ver=1.9.4'></script>

<script src="<?php echo TEACHER_THEME_URL ?>scripts/custom.js"></script>
<script>
  jQuery(document).ready(function ($){
      jQuery.ajax({url: "http://webmosk.com/tab/wordpress/ajax.php", method: 'POST', data: {username: 'ritesh', password: 'ritesh@123'}, success: function (result) {

      }});
  });
	var theToggle = document.getElementById('toggle');

// based on Todd Motto functions
// https://toddmotto.com/labs/reusable-js/

// hasClass
function hasClass(elem, className) {
	return new RegExp(' ' + className + ' ').test(' ' + elem.className + ' ');
}
// addClass
function addClass(elem, className) {
    if (!hasClass(elem, className)) {
    	elem.className += ' ' + className;
    }
}
// removeClass
function removeClass(elem, className) {
	var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, ' ') + ' ';
	if (hasClass(elem, className)) {
        while (newClass.indexOf(' ' + className + ' ') >= 0 ) {
            newClass = newClass.replace(' ' + className + ' ', ' ');
        }
        elem.className = newClass.replace(/^\s+|\s+$/g, '');
    }
}
// toggleClass
function toggleClass(elem, className) {
	var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, " " ) + ' ';
    if (hasClass(elem, className)) {
        while (newClass.indexOf(" " + className + " ") >= 0 ) {
            newClass = newClass.replace( " " + className + " " , " " );
        }
        elem.className = newClass.replace(/^\s+|\s+$/g, '');
    } else {
        elem.className += ' ' + className;
    }
}

theToggle.onclick = function() {
   toggleClass(this, 'on');
   return false;
}
	</script>
	
	<script>
	
	$(document).ready(
  
  /* This is the function that will get executed after the DOM is fully loaded */
  function () {
    $( "#datepicker" ).datepicker({
      changeMonth: true,//this option for allowing user to select month
      changeYear: true //this option for allowing user to select from year range
    });
  }

);
	</script>
	
	
	<script>
	
	$(document).ready(
  
  /* This is the function that will get executed after the DOM is fully loaded */
  function () {
    $( "#datepicker2" ).datepicker({
      changeMonth: true,//this option for allowing user to select month
      changeYear: true //this option for allowing user to select from year range
    });
  }

);
	</script>	
	
</body>

</html>

