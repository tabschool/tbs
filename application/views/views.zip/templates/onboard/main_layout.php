<?php $this->load->view('templates/onboard/main_header'); ?>

<?php $this->load->view($template); ?>

<?php $this->load->view('templates/onboard/main_footer'); ?>