<?php $this->load->view('templates/onboard/header'); ?>

<?php $this->load->view($template); ?>

<?php $this->load->view('templates/onboard/footer'); ?>