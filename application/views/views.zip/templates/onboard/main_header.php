<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tab School | Login</title>
    <!-- Core CSS - Include with every page -->
    <link href="<?php echo base_url('assets/mainfront/'); ?>plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="<?php echo base_url('assets/mainfront/'); ?>font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo base_url('assets/mainfront/'); ?>plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="<?php echo base_url('assets/mainfront/'); ?>css/style.css" rel="stylesheet" />
      <link href="<?php echo base_url('assets/mainfront/'); ?>css/main-style.css" rel="stylesheet" />
        <link href="<?php echo base_url('assets/mainfront/'); ?>css/datepicker3.css" rel="stylesheet" />
         <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

      <style type="text/css">.error{ color: red; }</style>
</head>

<body class="body-Login-back">

    <div class="log-header">
	    <div class="container">       
          <div class="row"> 
		     <div class="logo_log"><img src="<?php echo base_url('assets/mainfront/'); ?>img/logo.png"></div>
		  </div>
		</div>
	  
	</div>
	