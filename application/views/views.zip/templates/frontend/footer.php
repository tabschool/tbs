
   
     <!-- Core Scripts - Include with every page -->
    <script src="<?php echo FRONTEND_THEME_URL ?>plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo FRONTEND_THEME_URL ?>plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo FRONTEND_THEME_URL ?>plugins/metisMenu/jquery.metisMenu.js"></script>

</body>

</html>
