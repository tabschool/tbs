<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tab School | Login</title>
    <!-- Core CSS - Include with every page -->
    <link href="<?php echo FRONTEND_THEME_URL ?>plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="<?php echo FRONTEND_THEME_URL ?>font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo FRONTEND_THEME_URL ?>plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="<?php echo FRONTEND_THEME_URL ?>css/style.css" rel="stylesheet" />
      <link href="<?php echo FRONTEND_THEME_URL ?>css/main-style.css" rel="stylesheet" />

</head>

<body class="body-Login-back">

    <div class="log-header">
	    <div class="container">       
          <div class="row"> 
		     <div class="logo_log"><img src="<?php echo FRONTEND_THEME_URL ?>img/logo.png"></div>
		  </div>
		</div>
	  
	</div>
	
   

	
