<?php $this->load->view('templates/student/header'); ?>

<?php $this->load->view($template); ?>

<?php $this->load->view('templates/student/footer'); ?>