                      
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo STUDENT_THEME_URL ?>plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo STUDENT_THEME_URL ?>plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo STUDENT_THEME_URL ?>plugins/metisMenu/jquery.metisMenu.js"></script> 



<script type="text/javascript">
addLoadEvent = function(func){if(typeof jQuery!="undefined")jQuery(document).ready(func);else if(typeof wpOnload!='function'){wpOnload=func;}else{var oldonload=wpOnload;wpOnload=function(){oldonload();func();}}};
var ajaxurl = '/tab/wordpress/wp-admin/admin-ajax.php',
    pagenow = 'toplevel_page_h5p',
    typenow = '',
    adminpage = 'toplevel_page_h5p',
    thousandsSeparator = ',',
    decimalPoint = '.',
    isRtl = 0;
</script>


<script>H5PIntegration = {"baseUrl":"http:\/\/webmosk.com\/tab\/wordpress","url":"\/tab\/wordpress\/wp-content\/uploads\/h5p","postUserStatistics":true,"ajax":{"setFinished":"http:\/\/webmosk.com\/tab\/wordpress\/wp-admin\/admin-ajax.php?token=f1f33fd873&action=h5p_setFinished","contentUserData":"http:\/\/webmosk.com\/tab\/wordpress\/wp-admin\/admin-ajax.php?token=02ad7cbfa5&action=h5p_contents_user_data&content_id=:contentId&data_type=:dataType&sub_content_id=:subContentId"},"saveFreq":false,"siteUrl":"http:\/\/webmosk.com\/tab\/wordpress","l10n":{"H5P":{"fullscreen":"Fullscreen","disableFullscreen":"Disable fullscreen","download":"Download","copyrights":"Rights of use","embed":"Embed","size":"Size","showAdvanced":"Show advanced","hideAdvanced":"Hide advanced","advancedHelp":"Include this script on your website if you want dynamic sizing of the embedded content:","copyrightInformation":"Rights of use","close":"Close","title":"Title","author":"Author","year":"Year","source":"Source","license":"License","thumbnail":"Thumbnail","noCopyrights":"No copyright information available for this content.","downloadDescription":"Download this content as a H5P file.","copyrightsDescription":"View copyright information for this content.","embedDescription":"View the embed code for this content.","h5pDescription":"Visit H5P.org to check out more cool content.","contentChanged":"This content has changed since you last used it.","startingOver":"You'll be starting over.","by":"by","showMore":"Show more","showLess":"Show less","subLevel":"Sublevel","confirmDialogHeader":"Confirm action","confirmDialogBody":"Please confirm that you wish to proceed. This action is not reversible.","cancelLabel":"Cancel","confirmLabel":"Confirm","licenseU":"Undisclosed","licenseCCBY":"Attribution","licenseCCBYSA":"Attribution-ShareAlike","licenseCCBYND":"Attribution-NoDerivs","licenseCCBYNC":"Attribution-NonCommercial","licenseCCBYNCSA":"Attribution-NonCommercial-ShareAlike","licenseCCBYNCND":"Attribution-NonCommercial-NoDerivs","licenseCC40":"4.0 International","licenseCC30":"3.0 Unported","licenseCC25":"2.5 Generic","licenseCC20":"2.0 Generic","licenseCC10":"1.0 Generic","licenseGPL":"General Public License","licenseV3":"Version 3","licenseV2":"Version 2","licenseV1":"Version 1","licensePD":"Public Domain","licenseCC010":"CC0 1.0 Universal (CC0 1.0) Public Domain Dedication","licensePDM":"Public Domain Mark","licenseC":"Copyright"}},"hubIsEnabled":true,"user":{"name":"admin","mail":"harshpal.khurana@tabschool.in"},"core":{"styles":["\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p-confirmation-dialog.css?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/styles\/h5p-core-button.css?ver=1.9.4"],"scripts":["\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/jquery.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-event-dispatcher.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-x-api-event.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-x-api.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-content-type.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-confirmation-dialog.js?ver=1.9.4","\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-action-bar.js?ver=1.9.4"]},"loadedJs":[],"loadedCss":[],"contents":{"cid-1":{"library":"<?php echo $content_info->library_id; ?>","jsonContent":<?php echo $content_info->content; ?>,"fullScreen":"0","exportUrl":"\/tab\/wordpress\/wp-content\/uploads\/h5p\/exports\/this-is-the-title-1.h5p","embedCode":"<iframe src=\"http:\/\/webmosk.com\/tab\/wordpress\/wp-admin\/admin-ajax.php?action=h5p_embed&id=1\" width=\":w\" height=\":h\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"><\/iframe>","resizeCode":"<script src=\"http:\/\/webmosk.com\/tab\/wordpress\/wp-content\/plugins\/h5p\/h5p-php-library\/js\/h5p-resizer.js\" charset=\"UTF-8\"><\/script>","url":"http:\/\/webmosk.com\/tab\/wordpress\/wp-admin\/admin-ajax.php?action=h5p_embed&id=1","title":"this is the title","displayOptions":{"frame":true,"export":true,"embed":true,"copyright":true,"icon":true},"contentUserData":[{"state":"{}"}],"scripts":["\/tab\/wordpress\/wp-content\/uploads\/h5p\/cachedassets\/b7254897442c9cb2489730b5abe2f3fa7166ccdc.js"],"styles":["\/tab\/wordpress\/wp-content\/uploads\/h5p\/cachedassets\/b7254897442c9cb2489730b5abe2f3fa7166ccdc.css"]}}};</script>

<script type='text/javascript'>
/* <![CDATA[ */
var commonL10n = {"warnDelete":"You are about to permanently delete these items from your site.\nThis action cannot be undone.\n 'Cancel' to stop, 'OK' to delete.","dismiss":"Dismiss this notice.","collapseMenu":"Collapse Main menu","expandMenu":"Expand Main menu"};var heartbeatSettings = {"nonce":"a90de34ffc"};var authcheckL10n = {"beforeunload":"Your session has expired. You can log in again from this page or go to the login page.","interval":"180"};/* ]]> */
</script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-admin/load-scripts.php?c=1&amp;load%5B%5D=hoverIntent,common,admin-bar,svg-painter,heartbeat,wp-auth-check&amp;ver=4.8.3'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/jquery.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-event-dispatcher.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-x-api-event.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-x-api.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-content-type.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-confirmation-dialog.js?ver=1.9.4'></script>
<script type='text/javascript' src='http://webmosk.com/tab/wordpress/wp-content/plugins/h5p/h5p-php-library/js/h5p-action-bar.js?ver=1.9.4'></script>

<script>
var theToggle = document.getElementById('toggle');

// based on Todd Motto functions
// https://toddmotto.com/labs/reusable-js/

// hasClass
function hasClass(elem, className) {
    return new RegExp(' ' + className + ' ').test(' ' + elem.className + ' ');
}
// addClass
function addClass(elem, className) {
    if (!hasClass(elem, className)) {
        elem.className += ' ' + className;
    }
}
// removeClass
function removeClass(elem, className) {
    var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, ' ') + ' ';
    if (hasClass(elem, className)) {
        while (newClass.indexOf(' ' + className + ' ') >= 0 ) {
            newClass = newClass.replace(' ' + className + ' ', ' ');
        }
        elem.className = newClass.replace(/^\s+|\s+$/g, '');
    }
}
// toggleClass
function toggleClass(elem, className) {
    var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, " " ) + ' ';
    if (hasClass(elem, className)) {
        while (newClass.indexOf(" " + className + " ") >= 0 ) {
            newClass = newClass.replace( " " + className + " " , " " );
        }
        elem.className = newClass.replace(/^\s+|\s+$/g, '');
    } else {
        elem.className += ' ' + className;
    }
}

theToggle.onclick = function() {
   toggleClass(this, 'on');
   return false;
}
    </script>
    
</body>

</html>
