<?php $this->load->view('templates/institute/header'); ?>

<?php $this->load->view($template); ?>

<?php $this->load->view('templates/institute/footer'); ?>