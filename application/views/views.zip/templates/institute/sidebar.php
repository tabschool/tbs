<main>
<div class="row">
<div class="col l2 hide-on-med-and-down">
    	<div class="left-side-nav shadow">        	
        	<ul>
            	 <li><a href="<?php echo base_url(); ?>institute/dashboard" class="waves-effect waves-cyan">Dashboard</a></li>
                 <li><a href="<?php echo base_url(); ?>institute/institute/students" class="waves-effect waves-cyan">Students</a></li>
                 <li><a href="<?php echo base_url(); ?>institute/institute/teachers" class="waves-effect waves-cyan">Teachers</a></li>
                 <li><a href="<?php echo base_url(); ?>institute/courses/" class="waves-effect waves-cyan">Courses</a></li>
                 <li><a href="<?php echo base_url(); ?>institute/courses/categories" class="waves-effect waves-cyan">Course Category</a></li>
                                 
            </ul>
            <div class="bottom-nav">
            	<ul>
                    <li><a href="<?php echo base_url().'institute/institute/settings'; ?>" class="waves-effect waves-cyan">Settings</a></li>
                    <li><a href="http://www.tabschool.in/welcome/support" target="_blank" class="waves-effect waves-cyan">Helpdesk</a></li>
                    <li><a href="http://www.tabschool.in" class="waves-effect waves-cyan">About Tabschool</a></li>
                </ul>
            </div> 
        </div>
    </div>