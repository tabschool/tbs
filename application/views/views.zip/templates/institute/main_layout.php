<?php $this->load->view('templates/institute/main_header'); ?>

<?php $this->load->view($template); ?>

<?php $this->load->view('templates/institute/main_footer'); ?>