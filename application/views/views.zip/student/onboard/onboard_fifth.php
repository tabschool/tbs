  <div class="wrap"> 

    <!-- START CONTENT -->	

    <div class="onboard">

    	<div class="row">

        <div class="col s12 m12">

          <div class="card-bg-login">

          	<div class="onboard-wrap">

            <div class="progress-bar-wrap">

          	<div class="progress">

      		<div class="determinate" style="width:100%"></div>

  			</div>

            </div>

            <div class="steps">

            	<ul>

                	<li class="equal"><div class="cir-seps-brand"></div></li>

                    <li class="equal"><div class="cir-seps-brand"></div></li>

                    <li class="equal"><div class="cir-seps-brand"></div></li>

                    <li class="equal"><div class="cir-seps-brand"></div></li>

                    <li><div class="cir-seps-brand"></div></li>

                </ul>

            </div>

            

            <div class="row">

            <div class="col s12 m12 l12">

            <h5 style="margin-top:-28px !important;">Congratulations!!</h5>

            	  <h6>Thank you for choosing Tabschool as your education partner.

Now you are good to go </h6>

<h6><a class="waves-effect waves-light btn blue darken-4" href="<?php  echo  base_url('teacher/dashboard') ;   ?>" >Let's Go!</a></h6>

            </div>

            

            

            </div>

            </div>

           

            

             

            </div>

          </div>

        </div>

      </div>

  		

      </div>

    